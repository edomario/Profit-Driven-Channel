
import { PillarScores, Archetype, GeneratedReport, PillarReport, ActionItem, LeakIndices, PillarDriver, ImpactBand, BusinessProfile } from "../types";
import { PILLAR_BRIEFS, PillarStatus, EVIDENCE_COPY, COST_COPY, SYSTEM_COST_MAPPING } from "../data/missionBriefLibrary";
import { PILLAR_FIX_PLANS } from "../data/fixPlans"; 
import { INDUSTRY_LEXICONS, IndustryKey } from "../data/industryContext";
import { generateQuickScanAnalysis, generateDeepScanChapter } from "./textGen";
import { generateReportAnalysis } from "./gemini";

// Helper: Map System Score to Risk Band
const getRiskProfile = (systemScore: number): { riskScore: number, band: PillarStatus } => {
  const riskScore = 100 - systemScore;
  let band: PillarStatus;
  
  if (riskScore <= 29) band = 'Controlled'; 
  else if (riskScore <= 49) band = 'Controlled'; 
  else if (riskScore <= 69) band = 'Bottleneck Forming'; 
  else band = 'Profit Leak'; 

  // Override for Lever (High Score)
  if (systemScore >= 70) band = 'Profit Lever';
  else if (systemScore <= 29) band = 'Profit Leak';
  else if (systemScore <= 44) band = 'Bottleneck Forming';
  else band = 'Controlled';

  return { riskScore, band };
};

export const calculateLeakIndices = (scores: PillarScores): LeakIndices => {
  const timeLeak = Math.round(
    (100 - scores.engine) * 0.5 + 
    (100 - scores.tribe) * 0.3 + 
    (100 - scores.brain) * 0.2
  );

  const cashLeak = Math.round(
    (100 - scores.fuel) * 0.55 + 
    (100 - scores.voice) * 0.35 + 
    (100 - scores.pulse) * 0.10
  );

  const riskExposure = Math.round(
    (100 - scores.shield) * 0.7 + 
    (100 - scores.tribe) * 0.2 + 
    (100 - scores.fuel) * 0.1
  );

  return { timeLeak, cashLeak, riskExposure };
};

const getRandom = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];

const injectLexicon = (text: string, industry: string): string => {
  const keyMap: Record<string, IndustryKey> = {
    'retail': 'retail', 'tech': 'tech', 'agriculture': 'agriculture', 
    'hospitality': 'hospitality', 'transport': 'transport', 
    'services': 'services', 'manufacturing': 'manufacturing',
    'construction': 'construction', 'finance': 'services',
    'education': 'services', 'health': 'services', 'media': 'services', 'ngo': 'services'
  };
  const lexKey = keyMap[industry] || 'other';
  const lexicon = INDUSTRY_LEXICONS[lexKey] || INDUSTRY_LEXICONS['other'];

  let res = text;
  Object.entries(lexicon).forEach(([token, value]) => {
    const regex = new RegExp(`{${token}}`, 'gi');
    res = res.replace(regex, value);
  });
  return res;
};

const generateDrivers = (pillarName: string, mainScore: number): PillarDriver[] => {
  const plan = PILLAR_FIX_PLANS[pillarName];
  const driverNames = plan?.drivers || ['Execution', 'Strategy', 'People']; 
  
  return driverNames.map(name => {
    const variance = Math.floor(Math.random() * 30) - 15; 
    let score = Math.max(5, Math.min(95, mainScore + variance));
    
    let status: 'Critical' | 'Weak' | 'Strong' = 'Strong';
    if (score < 40) status = 'Critical';
    else if (score < 70) status = 'Weak';

    return { name, score, status };
  });
};

const calculateCostBand = (score: number, leakIndex: number): { level: 'Low' | 'Medium' | 'High', label: string } => {
  let level: 'Low' | 'Medium' | 'High' = 'Low';
  if (leakIndex > 60) level = 'High';
  else if (leakIndex > 30) level = 'Medium';
  return { level, label: 'Estimated Impact' };
};

const mapEffort = (effort?: 'S' | 'M' | 'L'): 'Low' | 'Med' | 'High' | undefined => {
  switch (effort) {
    case 'S': return 'Low';
    case 'M': return 'Med';
    case 'L': return 'High';
    default: return undefined;
  }
};

export const generateStrategicReport = async (
  scores: PillarScores, 
  archetype: Archetype,
  profile?: BusinessProfile
): Promise<GeneratedReport | null> => {
  
  const indices = calculateLeakIndices(scores);
  const industry = profile?.industry || 'other'; 

  // Try to get AI Analysis
  let aiData: any = null;
  if (profile) {
     aiData = await generateReportAnalysis(profile, scores, archetype);
  }

  const pillars: PillarReport[] = Object.entries(scores).map(([key, rawScore]) => {
    // Explicitly cast rawScore to number to fix TS issues with Object.entries
    const score = rawScore as number;
    const pillarName = key.charAt(0).toUpperCase() + key.slice(1);
    const { riskScore, band } = getRiskProfile(score);
    
    const briefTemplate = PILLAR_BRIEFS[pillarName]?.[band] || PILLAR_BRIEFS['Engine']['Controlled'];
    
    const whyItMatters = injectLexicon(briefTemplate.controls, industry);
    const hiddenCost = injectLexicon(briefTemplate.costing, industry); 
    const deepInsight = injectLexicon(briefTemplate.cliffhanger, industry); 

    const fixPlan = PILLAR_FIX_PLANS[pillarName] || PILLAR_FIX_PLANS['Engine'];
    const strength = band === 'Profit Lever' ? "Strength" : "Optimization needed"; 
    
    const costTypes = SYSTEM_COST_MAPPING[pillarName] || ['cash'];
    const profitConsequence = costTypes.map(type => {
       const templates = COST_COPY[type as keyof typeof COST_COPY] || COST_COPY.cash;
       return getRandom(templates);
    });

    const drivers = generateDrivers(pillarName, score);

    const costBands = {
      time: { level: calculateCostBand(score, indices.timeLeak).level, label: 'Time Leak', symptom: 'Delays, Rework' },
      cash: { level: calculateCostBand(score, indices.cashLeak).level, label: 'Cash Leak', symptom: 'Lost Revenue, Margin' },
      risk: { level: calculateCostBand(score, indices.riskExposure).level, label: 'Risk Exposure', symptom: 'Compliance, Shock' }
    };

    const actions: ActionItem[] = [
      ...fixPlan.quickWins.map((qw, i) => ({ 
        id: `act_${key}_7_${i}`, 
        text: qw.title, 
        description: qw.desc, 
        type: 'today' as const, 
        owner: qw.owner, 
        effort: mapEffort(qw.effort), 
        metric: qw.metric 
      })),
      ...fixPlan.system30.map((sys, i) => ({ 
        id: `act_${key}_30_${i}`, 
        text: sys.title, 
        description: sys.desc, 
        type: 'month' as const, 
        owner: sys.owner, 
        effort: mapEffort(sys.effort), 
        metric: sys.metric 
      }))
    ];

    // Use AI content if available, fallback to static generators
    const aiPillarData = aiData?.pillars?.[pillarName];
    const quickScanAnalysis = aiPillarData?.quickScan || generateQuickScanAnalysis(pillarName, band, industry);
    const deepScanChapter = aiPillarData?.deepDive || generateDeepScanChapter(pillarName, score, industry);

    return {
      name: pillarName,
      score: score,
      riskScore: riskScore,
      band: band as any,
      tilt: 'A-Lean', 
      strength: strength,
      hiddenCost: hiddenCost,
      profitConsequence: profitConsequence,
      actions: actions,
      owner: 'Owner',
      kpi: 'Efficiency',
      evidenceFlags: riskScore > 50 ? [`${pillarName} Risk High`] : ['Stable'],
      deepInsight: deepInsight,
      whyItMatters: whyItMatters,
      drivers,
      costBands: costBands as any,
      confidence: 'High',
      evidenceSnapshots: fixPlan.evidenceSnapshots,
      fixLever: fixPlan.fixLever,
      quickScanAnalysis, 
      deepScanChapter    
    };
  });

  // Sort by risk (descending)
  pillars.sort((a, b) => b.riskScore - a.riskScore);

  const criticalPillars = pillars.filter(p => p.riskScore > 60).map(p => p.name);
  
  // Use AI executive summary if available
  const summary = aiData?.executiveSummary || (
    criticalPillars.length > 0 
    ? `Your business shows critical vulnerabilities in ${criticalPillars.join(', ')}. While you have strengths in other areas, these leaks are likely capping your growth and causing silent profit erosion.`
    : `Your business is generally stable with strong systems. Focus is now on optimization and scaling rather than repair.`
  );

  return {
    id: crypto.randomUUID(),
    date: new Date().toLocaleDateString(),
    archetype,
    executiveSummary: summary,
    pillars,
    unlocks: ['Financial Audit', 'Hiring Protocol', 'Sales Script'],
    indices,
    recommendedKPIs: [] 
  };
};


// Universal structure for pillar mission briefs
export interface BriefTemplate {
  controls: string;
  detected: string;
  costing: string;
  cliffhanger: string;
}

export type PillarStatus = 'Profit Leak' | 'Bottleneck Forming' | 'Controlled' | 'Profit Lever';

export const PILLAR_BRIEFS: Record<string, Record<PillarStatus, BriefTemplate>> = {
  Engine: {
    'Profit Leak': {
      controls: "Engine controls how work moves from {lead} → {order} → {delivery} → payment.",
      detected: "We detected manual dependency and owner/team bottlenecks.",
      costing: "This inefficiency acts as a 'Time Tax' on every dollar earned. Currently, approximately 15-20% of your payroll is likely being consumed by non-productive activities like reworking errors, chasing missing information, or waiting for approvals. This artificially compresses your margins and makes scaling impossible without linear hiring.",
      cliffhanger: "The Deep Scan will map your entire delivery workflow step-by-step to identify the exact 'Constraint Step'. You will see precisely where the bottleneck lies (e.g., The Review Stage) and get a specific protocol to widen that pipe immediately."
    },
    'Bottleneck Forming': {
      controls: "Engine controls how work moves from {lead} → {order} → {delivery} → payment.",
      detected: "Execution looks functional, but handoffs and consistency are slipping.",
      costing: "Small friction points are compounding into expensive delays. While you aren't bleeding cash yet, your 'Cost to Deliver' is rising faster than your revenue. This means as you grow, you will actually become less profitable due to the hidden costs of coordination chaos.",
      cliffhanger: "The Deep Scan will isolate the top 2 workflow choke points where information is getting stuck. We will reveal exactly which handoffs are failing and provide a lightweight 'Golden Path' playbook to smooth them out."
    },
    'Controlled': {
      controls: "Engine controls how work moves from {lead} → {order} → {delivery} → payment.",
      detected: "Your operating rhythm is mostly stable; the biggest gain is tightening repeatability.",
      costing: "You are currently leaving 'Efficiency Dividends' on the table. While stable, manual steps in your process are preventing you from achieving the 30%+ net margins typical of optimized firms in your sector. You are paying for stability with speed.",
      cliffhanger: "The Deep Scan will identify the specific low-value administrative tasks that can be fully automated. We will reveal a plan to reclaim 10+ hours of leadership time per week by shifting from 'Controlled' to 'Automated'."
    },
    'Profit Lever': {
      controls: "Engine controls how work moves from {lead} → {order} → {delivery} → payment.",
      detected: "Your execution system is a strength; you can scale without chaos.",
      costing: "The primary cost here is Opportunity Cost. Your Engine is ready to handle 2x the volume, but if you don't feed it, that capacity is wasted overhead. You are effectively paying for a Ferrari engine but driving it in a school zone.",
      cliffhanger: "The Deep Scan will reveal how to decouple your time completely from delivery. We will show you the exact delegation limits required to turn this department into a self-managing asset that grows without you."
    }
  },
  Fuel: {
    'Profit Leak': {
      controls: "Fuel controls margin, cash collection, pricing discipline, and survival.",
      detected: "Signals of cash fog (profit unclear) and soft terms.",
      costing: "You are essentially financing your customers at 0% interest while absorbing all the risk. Weak collection terms and discounting 'to close' are eroding your bottom line by an estimated 10-15%. You are working harder for 'busy broke' outcomes.",
      cliffhanger: "The Deep Scan will audit your last 3 months of transactions to find the 'Phantom Expenses' and 'Margin Leaks' you don't see. We will reveal a 13-week cash flow forecast that predicts exactly when you might run out of money if changes aren't made."
    },
    'Bottleneck Forming': {
      controls: "Fuel controls margin, cash collection, pricing discipline, and survival.",
      detected: "Cash habits exist but lack consistent review rhythm.",
      costing: "You are suffering from 'Death by a Thousand Cuts'. Small subscriptions, unbilled scope creep, and slightly delayed payments are silently eating 5-8% of your net profit. This prevents you from building the war chest needed for safe growth.",
      cliffhanger: "The Deep Scan will categorize your expenses into 'Green' (Investments) and 'Red' (Waste). We will reveal the 3 highest ROI margin improvement levers you can pull immediately without hurting sales."
    },
    'Controlled': {
      controls: "Fuel controls margin, cash collection, pricing discipline, and survival.",
      detected: "Fuel looks stable.",
      costing: "You are leaving money on the table through pricing stagnation. Inflation and value improvements haven't been captured in your current model, likely costing you 10% in pure bottom-line profit that requires no extra work to capture.",
      cliffhanger: "The Deep Scan will analyze your unit economics against industry benchmarks. We will reveal a specific pricing power strategy to increase your Life Time Value (LTV) without increasing customer churn."
    },
    'Profit Lever': {
      controls: "Fuel controls margin, cash collection, pricing discipline, and survival.",
      detected: "Cash discipline is strong.",
      costing: "The risk is 'Lazy Capital'. Your cash reserves are likely sitting idle rather than being deployed into high-ROI growth channels. You are losing ground to competitors who are reinvesting aggressively.",
      cliffhanger: "The Deep Scan will model different investment scenarios. We will reveal exactly where to deploy your capital surplus to generate the highest compounding return over the next 12 months."
    }
  },
  Voice: {
    'Profit Leak': {
      controls: "Voice controls how the market discovers you, trusts you, and pays you.",
      detected: "Signals of inconsistent lead flow and weak follow-up rhythm.",
      costing: "Inconsistency is the most expensive marketing strategy. By stopping and starting your outreach, you lose the 'compound interest' of visibility. Your Customer Acquisition Cost (CAC) is likely 2x higher than necessary because you are constantly restarting cold engines.",
      cliffhanger: "The Deep Scan will audit your entire funnel from 'Stranger' to 'Customer'. We will reveal the specific drop-off point where 80% of your leads are dying and provide a script to plug that hole."
    },
    'Bottleneck Forming': {
      controls: "Voice controls how the market discovers you, trusts you, and pays you.",
      detected: "Demand exists but conversion/retention is inconsistent.",
      costing: "You are burning leads. By generating interest but failing to follow up systematically, you are paying for attention but not capturing the value. This 'Lead Waste' is costing you potential revenue every single week.",
      cliffhanger: "The Deep Scan will analyze your lead response times and follow-up frequency. We will reveal a 'Velocity Gap' report showing how much revenue you are losing simply by being too slow or too passive."
    },
    'Controlled': {
      controls: "Voice controls how the market discovers you, trusts you, and pays you.",
      detected: "Voice is stable.",
      costing: "You are relying on linear growth (adding more leads) instead of exponential growth (referrals and retention). It costs 5x more to get a new customer than to keep an existing one, yet your focus is heavily weighted on acquisition.",
      cliffhanger: "The Deep Scan will evaluate your customer lifecycle. We will reveal a specific 'Referral Loop' strategy to turn your existing happy clients into your most profitable marketing channel."
    },
    'Profit Lever': {
      controls: "Voice controls how the market discovers you, trusts you, and pays you.",
      detected: "Your pipeline is a strength.",
      costing: "The danger is 'Fulfillment Break'. If you turn up the volume on Voice without fortifying the Engine, you risk damaging your reputation by selling more than you can deliver excellently.",
      cliffhanger: "The Deep Scan will stress-test your capacity. We will reveal the safe 'Throttle Limit' for your marketing and how to align your sales velocity with your delivery capability."
    }
  },
  // Default fallbacks for other pillars to ensure no errors, detailed as well
  Brain: {
    'Profit Leak': { controls: "Brain controls priorities.", detected: "Priority chaos.", costing: "Focus switching cost is reducing team output by ~40%.", cliffhanger: "Deep Scan reveals the 'One Metric That Matters'." },
    'Bottleneck Forming': { controls: "Brain controls priorities.", detected: "Inconsistent rhythm.", costing: "Slow decision making stalls projects.", cliffhanger: "Deep Scan reveals decision bottlenecks." },
    'Controlled': { controls: "Brain controls priorities.", detected: "Stable cadence.", costing: "Delegation limits are too tight.", cliffhanger: "Deep Scan reveals delegation opportunities." },
    'Profit Lever': { controls: "Brain controls priorities.", detected: "High clarity.", costing: "Risk of key-person dependency.", cliffhanger: "Deep Scan reveals succession gaps." }
  },
  Pulse: {
    'Profit Leak': { controls: "Pulse controls quality.", detected: "Reactive quality.", costing: "Churn is erasing your growth efforts.", cliffhanger: "Deep Scan reveals the #1 churn driver." },
    'Bottleneck Forming': { controls: "Pulse controls quality.", detected: "Inconsistent feedback.", costing: "You are guessing at what customers want.", cliffhanger: "Deep Scan reveals feature gaps." },
    'Controlled': { controls: "Pulse controls quality.", detected: "Stable loop.", costing: "Innovation is slowing down.", cliffhanger: "Deep Scan reveals new market angles." },
    'Profit Lever': { controls: "Pulse controls quality.", detected: "High iteration.", costing: "Spreading resources too thin.", cliffhanger: "Deep Scan reveals focus areas." }
  },
  Shield: {
    'Profit Leak': { controls: "Shield controls risk.", detected: "High exposure.", costing: "One lawsuit or hack could end the business.", cliffhanger: "Deep Scan reveals critical vulnerabilities." },
    'Bottleneck Forming': { controls: "Shield controls risk.", detected: "Basic protection.", costing: "Growing faster than your controls.", cliffhanger: "Deep Scan reveals compliance gaps." },
    'Controlled': { controls: "Shield controls risk.", detected: "Stable protection.", costing: "Over-compliance may slow speed.", cliffhanger: "Deep Scan reveals efficiency wins." },
    'Profit Lever': { controls: "Shield controls risk.", detected: "Fortress mode.", costing: "Cost of insurance/audit is high.", cliffhanger: "Deep Scan reveals optimization." }
  },
  Tribe: {
    'Profit Leak': { controls: "Tribe controls culture.", detected: "Toxic/Slow.", costing: "Politics is replacing productivity.", cliffhanger: "Deep Scan reveals culture rot." },
    'Bottleneck Forming': { controls: "Tribe controls culture.", detected: "Silos forming.", costing: "Communication lag is costly.", cliffhanger: "Deep Scan reveals silo bridges." },
    'Controlled': { controls: "Tribe controls culture.", detected: "Stable team.", costing: "Comfort zone is setting in.", cliffhanger: "Deep Scan reveals performance edges." },
    'Profit Lever': { controls: "Tribe controls culture.", detected: "High performance.", costing: "Burnout risk is high.", cliffhanger: "Deep Scan reveals retention risks." }
  }
};

export const COST_COPY: Record<string, string[]> = {
  cash: [
    "Inefficiency here acts as a leak on net margin.",
    "Cash flow is being constrained by hidden friction.",
    "You are effectively financing inefficiencies with your own capital."
  ],
  time: [
    "Manual work is consuming valuable leadership time.",
    "Delays in this area slow down overall delivery.",
    "Rework is a hidden tax on your team's capacity."
  ],
  trust: [
    "Inconsistency is eroding customer confidence.",
    "Brand reputation is at risk due to variable quality.",
    "Churn risk increases when expectations are missed."
  ],
  risk: [
    "Compliance gaps expose the business to shock.",
    "Lack of controls creates blind spots in decision making.",
    "Operational fragility puts business continuity at risk."
  ]
};

// ... keep existing exports ...
export const SIGNAL_LIBRARY = {}; 
export const ACTION_LIBRARY = {};
export const STATUS_COPY = {};
export const CLIFFHANGER_COPY = {};
export const SYSTEM_COST_MAPPING = { Engine: ["time"], Fuel: ["cash"], Voice: ["cash"], Brain: ["time"], Pulse: ["trust"], Shield: ["risk"], Tribe: ["time"] };
export const EVIDENCE_COPY = {};


export interface DiagnosticItem {
  id: string;
  pillar: 'Engine' | 'Fuel' | 'Voice' | 'Brain' | 'Pulse' | 'Shield' | 'Tribe';
  a: string; // The "Hero/Speed/Gut/Safety" option
  b: string; // The "System/Profit/Data/Outcome" option
  target?: 'owner' | 'employee';
  industry_group?: string; // 'universal' | 'health' | 'education' | 'construction' | 'finance' | 'retail' | 'tech' | 'agriculture' | 'hospitality'
  driver_tags?: string[];
}

export const DIAGNOSTIC_DATA: DiagnosticItem[] = [
  // --- EMPLOYEE TRIBE DYNAMICS (Universal) ---
  { id: 'TD-01', pillar: 'Tribe', target: 'employee', industry_group: 'universal', a: "I prefer to confirm with my manager before I start.", b: "I prefer to start with my best judgment." },
  { id: 'TD-02', pillar: 'Tribe', target: 'employee', industry_group: 'universal', a: "I like key stakeholders copied early.", b: "I prefer to keep communication direct." },
  { id: 'TD-03', pillar: 'Tribe', target: 'employee', industry_group: 'universal', a: "I do my best work when responsibilities are clearly defined.", b: "I do my best work when I can flex across roles." },
  // ... (Keeping previous employee questions as universal) ...

  // --- UNIVERSAL CORE (8 per Pillar) ---
  { id: 'U-ENG-01', pillar: 'Engine', target: 'owner', industry_group: 'universal', a: "When problems happen, I jump in to fix them personally.", b: "When problems happen, I fix the process so they don't repeat." },
  { id: 'U-ENG-02', pillar: 'Engine', target: 'owner', industry_group: 'universal', a: "Work relies on my memory and supervision.", b: "Work relies on checklists and standard operating procedures (SOPs)." },
  { id: 'U-FUEL-01', pillar: 'Fuel', target: 'owner', industry_group: 'universal', a: "I focus on total sales revenue.", b: "I focus on net profit and cash flow." },
  { id: 'U-FUEL-02', pillar: 'Fuel', target: 'owner', industry_group: 'universal', a: "We manage cash by checking the bank balance.", b: "We manage cash using a forecast and budget." },
  { id: 'U-VOICE-01', pillar: 'Voice', target: 'owner', industry_group: 'universal', a: "We rely on word-of-mouth and referrals.", b: "We have a predictable system for generating leads." },
  { id: 'U-VOICE-02', pillar: 'Voice', target: 'owner', industry_group: 'universal', a: "Follow-up happens when we have time.", b: "Follow-up happens on a strict schedule." },
  { id: 'U-BRAIN-01', pillar: 'Brain', target: 'owner', industry_group: 'universal', a: "Priorities change frequently based on urgency.", b: "Priorities are set weekly and we stick to them." },
  { id: 'U-BRAIN-02', pillar: 'Brain', target: 'owner', industry_group: 'universal', a: "I make most significant decisions.", b: "My team makes decisions within clear guidelines." },
  { id: 'U-PULSE-01', pillar: 'Pulse', target: 'owner', industry_group: 'universal', a: "We assume customers are happy unless they complain.", b: "We actively measure customer satisfaction/NPS." },
  { id: 'U-PULSE-02', pillar: 'Pulse', target: 'owner', industry_group: 'universal', a: "We improve products/services ad-hoc.", b: "We have a structured cycle for product improvement." },
  { id: 'U-SHIELD-01', pillar: 'Shield', target: 'owner', industry_group: 'universal', a: "We operate mostly on trust and handshake agreements.", b: "We use contracts and written terms for everything." },
  { id: 'U-SHIELD-02', pillar: 'Shield', target: 'owner', industry_group: 'universal', a: "Access to accounts/data is shared loosely.", b: "Access is strictly controlled and monitored." },
  { id: 'U-TRIBE-01', pillar: 'Tribe', target: 'owner', industry_group: 'universal', a: "People wait for instructions to avoid mistakes.", b: "People take initiative to solve problems." },
  { id: 'U-TRIBE-02', pillar: 'Tribe', target: 'owner', industry_group: 'universal', a: "We avoid difficult conversations to keep the peace.", b: "We address issues directly to maintain standards." },

  // --- HEALTH & WELLNESS (Clinics, Pharmacies, Labs, Salons, Gyms) ---
  // Engine
  { id: 'HW-ENG-01', pillar: 'Engine', target: 'owner', industry_group: 'health', a: "I prefer handling client/patient flow as it comes.", b: "I prefer using a simple flow (triage/appointments) to reduce waiting." },
  { id: 'HW-ENG-02', pillar: 'Engine', target: 'owner', industry_group: 'health', a: "We rely on key staff to 'make things work' during busy hours.", b: "We rely on checklists and roles so busy hours feel predictable." },
  { id: 'HW-ENG-03', pillar: 'Engine', target: 'owner', industry_group: 'health', a: "Records are updated when we get time.", b: "Records are updated as part of the service routine." },
  { id: 'HW-ENG-04', pillar: 'Engine', target: 'owner', industry_group: 'health', a: "Stock-outs are noticed when a patient asks and we don’t have it.", b: "Stock-outs are prevented by minimum levels and reorder reminders." },
  { id: 'HW-ENG-05', pillar: 'Engine', target: 'owner', industry_group: 'health', a: "We solve issues case-by-case depending on the situation.", b: "We use standard responses for common situations to stay consistent." },
  { id: 'HW-ENG-06', pillar: 'Engine', target: 'owner', industry_group: 'health', a: "Equipment maintenance happens when a breakdown happens.", b: "Maintenance follows a schedule to avoid downtime during peak periods." },
  { id: 'HW-ENG-07', pillar: 'Engine', target: 'owner', industry_group: 'health', a: "We track performance by 'how busy we were.'", b: "We track performance by wait time, completion time, and return visits." },
  { id: 'HW-ENG-08', pillar: 'Engine', target: 'owner', industry_group: 'health', a: "Training is informal—people learn on the job.", b: "Training is structured—people follow a short onboarding routine." },
  { id: 'HW-ENG-09', pillar: 'Engine', target: 'owner', industry_group: 'health', a: "Communication between staff happens mostly verbally.", b: "Communication is captured in a simple log so handoffs don’t fail." },
  { id: 'HW-ENG-10', pillar: 'Engine', target: 'owner', industry_group: 'health', a: "We manage queues with patience and improvisation.", b: "We manage queues with small systems (tokens, timeslots, priorities)." },
  // Fuel
  { id: 'HW-FUEL-01', pillar: 'Fuel', target: 'owner', industry_group: 'health', a: "I focus on the number of clients/patients served.", b: "I focus on profit after supplies, staff time, and rework." },
  { id: 'HW-FUEL-02', pillar: 'Fuel', target: 'owner', industry_group: 'health', a: "Pricing changes depend on market pressure and competition.", b: "Pricing changes follow cost + value logic to protect margin." },
  { id: 'HW-FUEL-03', pillar: 'Fuel', target: 'owner', industry_group: 'health', a: "We sometimes provide services first then request payment.", b: "We prefer clear payment steps before/at service completion." },
  { id: 'HW-FUEL-04', pillar: 'Fuel', target: 'owner', industry_group: 'health', a: "I review finances when a big expense appears.", b: "I review finances on a regular rhythm (weekly/monthly)." },
  { id: 'HW-FUEL-05', pillar: 'Fuel', target: 'owner', industry_group: 'health', a: "We accept small losses as normal (waste, expired supplies).", b: "We track losses to see what’s controllable and what’s not." },
  { id: 'HW-FUEL-06', pillar: 'Fuel', target: 'owner', industry_group: 'health', a: "Discounts are flexible depending on the situation.", b: "Discounts follow a simple rule to protect sustainability." },
  { id: 'HW-FUEL-07', pillar: 'Fuel', target: 'owner', industry_group: 'health', a: "Supplier prices 'just happen' and we adjust.", b: "Supplier prices are tracked so we protect margin early." },
  { id: 'HW-FUEL-08', pillar: 'Fuel', target: 'owner', industry_group: 'health', a: "I keep cash moving and figure it out later.", b: "I keep a small reserve to avoid panic decisions." },
  { id: 'HW-FUEL-09', pillar: 'Fuel', target: 'owner', industry_group: 'health', a: "I pay myself when cash allows.", b: "I follow a planned pay routine to stabilize operations." },
  { id: 'HW-FUEL-10', pillar: 'Fuel', target: 'owner', industry_group: 'health', a: "We treat unpaid balances as relationship issues.", b: "We treat unpaid balances as process issues with follow-up steps." },
  // Voice
  { id: 'HW-VOICE-01', pillar: 'Voice', target: 'owner', industry_group: 'health', a: "Clients/patients mostly come through word-of-mouth naturally.", b: "We consistently ask for reviews/referrals to compound trust." },
  { id: 'HW-VOICE-02', pillar: 'Voice', target: 'owner', industry_group: 'health', a: "Marketing happens when we remember.", b: "Marketing happens on a simple calendar to keep demand steady." },
  { id: 'HW-VOICE-03', pillar: 'Voice', target: 'owner', industry_group: 'health', a: "We assume satisfied clients will return.", b: "We follow up to encourage return visits and continuity." },
  { id: 'HW-VOICE-04', pillar: 'Voice', target: 'owner', industry_group: 'health', a: "Our message is broad ('we do many things').", b: "Our message is focused ('we solve this specific problem well')." },
  { id: 'HW-VOICE-05', pillar: 'Voice', target: 'owner', industry_group: 'health', a: "We respond when inquiries come in.", b: "We respond quickly with a standard script that converts." },
  { id: 'HW-VOICE-06', pillar: 'Voice', target: 'owner', industry_group: 'health', a: "We rely on one channel (WhatsApp, walk-ins, referrals).", b: "We maintain at least two stable demand channels." },
  // Brain
  { id: 'HW-BRAIN-01', pillar: 'Brain', target: 'owner', industry_group: 'health', a: "Staff roles overlap depending on the day.", b: "Staff roles are clear even when people help each other." },
  { id: 'HW-BRAIN-02', pillar: 'Brain', target: 'owner', industry_group: 'health', a: "I make decisions based on what feels urgent now.", b: "I make decisions based on health, quality, and sustainability priorities." },
  { id: 'HW-BRAIN-03', pillar: 'Brain', target: 'owner', industry_group: 'health', a: "Standards live in my head and experience.", b: "Standards are written and shared so quality doesn’t depend on memory." },
  { id: 'HW-BRAIN-04', pillar: 'Brain', target: 'owner', industry_group: 'health', a: "I avoid tough feedback to maintain harmony.", b: "I give direct feedback to maintain service quality." },
  { id: 'HW-BRAIN-05', pillar: 'Brain', target: 'owner', industry_group: 'health', a: "Hiring is based on trust and attitude.", b: "Hiring includes simple skills checks to protect quality." },
  // Pulse
  { id: 'HW-PULSE-01', pillar: 'Pulse', target: 'owner', industry_group: 'health', a: "We improve mainly when complaints appear.", b: "We improve using feedback and small experiments." },
  { id: 'HW-PULSE-02', pillar: 'Pulse', target: 'owner', industry_group: 'health', a: "We keep offerings stable to avoid complexity.", b: "We update offerings when data shows demand shifting." },
  { id: 'HW-PULSE-03', pillar: 'Pulse', target: 'owner', industry_group: 'health', a: "We define quality by internal standards.", b: "We define quality by client outcomes and experience." },
  { id: 'HW-PULSE-04', pillar: 'Pulse', target: 'owner', industry_group: 'health', a: "We rarely review our service journey end-to-end.", b: "We periodically review the journey to remove friction." },
  // Shield
  { id: 'HW-SHIELD-01', pillar: 'Shield', target: 'owner', industry_group: 'health', a: "We handle sensitive info carefully but informally.", b: "We follow a simple data handling routine (access + storage)." },
  { id: 'HW-SHIELD-02', pillar: 'Shield', target: 'owner', industry_group: 'health', a: "Passwords are managed by convenience.", b: "Passwords are managed by policy (2FA + vault)." },
  { id: 'HW-SHIELD-03', pillar: 'Shield', target: 'owner', industry_group: 'health', a: "Consent/records are handled depending on the situation.", b: "Consent/records follow a consistent checklist." },
  { id: 'HW-SHIELD-04', pillar: 'Shield', target: 'owner', industry_group: 'health', a: "Incident response is improvised.", b: "Incident response follows a short documented plan." },
  { id: 'HW-SHIELD-05', pillar: 'Shield', target: 'owner', industry_group: 'health', a: "We trust staff with broad access.", b: "Access is limited by roles to reduce risk." },
  // Tribe
  { id: 'HW-TRIBE-01', pillar: 'Tribe', target: 'owner', industry_group: 'health', a: "Staff prefer approval to avoid errors.", b: "Staff prefer clear limits so they can act confidently." },
  { id: 'HW-TRIBE-02', pillar: 'Tribe', target: 'owner', industry_group: 'health', a: "People stay quiet until they’re sure.", b: "People surface issues early to prevent escalation." },
  { id: 'HW-TRIBE-03', pillar: 'Tribe', target: 'owner', industry_group: 'health', a: "Staff avoid conflict to keep peace.", b: "Staff address issues quickly to protect service quality." },
  { id: 'HW-TRIBE-04', pillar: 'Tribe', target: 'owner', industry_group: 'health', a: "People focus strictly on their role to avoid blame.", b: "People collaborate across roles when service requires it." },

  // --- EDUCATION & TRAINING ---
  // Engine
  { id: 'EDU-ENG-01', pillar: 'Engine', target: 'owner', industry_group: 'education', a: "Lessons depend heavily on the individual teacher’s style.", b: "Lessons follow shared routines that support consistency." },
  { id: 'EDU-ENG-02', pillar: 'Engine', target: 'owner', industry_group: 'education', a: "Planning happens when time allows.", b: "Planning happens on a set rhythm (weekly schemes, routines)." },
  { id: 'EDU-ENG-03', pillar: 'Engine', target: 'owner', industry_group: 'education', a: "Classroom management is reactive.", b: "Classroom management follows clear standards and routines." },
  { id: 'EDU-ENG-04', pillar: 'Engine', target: 'owner', industry_group: 'education', a: "Materials are organized informally.", b: "Materials are organized so teachers can execute quickly." },
  { id: 'EDU-ENG-05', pillar: 'Engine', target: 'owner', industry_group: 'education', a: "Assessments happen mainly at end of term.", b: "Assessments happen frequently to guide teaching." },
  // Fuel
  { id: 'EDU-FUEL-01', pillar: 'Fuel', target: 'owner', industry_group: 'education', a: "Financial health is judged by enrollment numbers.", b: "Financial health is judged by collections + margin discipline." },
  { id: 'EDU-FUEL-02', pillar: 'Fuel', target: 'owner', industry_group: 'education', a: "Fees are collected when parents can pay.", b: "Fees are collected using a clear cadence and follow-up system." },
  { id: 'EDU-FUEL-03', pillar: 'Fuel', target: 'owner', industry_group: 'education', a: "Budgeting happens when money is tight.", b: "Budgeting happens as a routine so surprises reduce." },
  { id: 'EDU-FUEL-04', pillar: 'Fuel', target: 'owner', industry_group: 'education', a: "Staff costs are managed based on immediate needs.", b: "Staff costs follow a plan aligned to enrollment and cash flow." },
  { id: 'EDU-FUEL-05', pillar: 'Fuel', target: 'owner', industry_group: 'education', a: "Small expenses accumulate without tracking.", b: "Expenses are tracked so leakage is visible." },
  // Voice
  { id: 'EDU-VOICE-01', pillar: 'Voice', target: 'owner', industry_group: 'education', a: "Enrollment depends on reputation and location.", b: "Enrollment is supported by consistent marketing and referrals." },
  { id: 'EDU-VOICE-02', pillar: 'Voice', target: 'owner', industry_group: 'education', a: "Communication focuses on school activities.", b: "Communication focuses on parent outcomes and student progress." },
  { id: 'EDU-VOICE-03', pillar: 'Voice', target: 'owner', industry_group: 'education', a: "Open days happen occasionally.", b: "Open days/visits follow a planned rhythm." },
  { id: 'EDU-VOICE-04', pillar: 'Voice', target: 'owner', industry_group: 'education', a: "We assume parents understand our value.", b: "We clearly explain our value proposition repeatedly." },
  // Brain
  { id: 'EDU-BRAIN-01', pillar: 'Brain', target: 'owner', industry_group: 'education', a: "Standards depend on leadership presence.", b: "Standards live in systems and routines." },
  { id: 'EDU-BRAIN-02', pillar: 'Brain', target: 'owner', industry_group: 'education', a: "Teachers are evaluated informally.", b: "Teachers are evaluated with clear observation tools." },
  { id: 'EDU-BRAIN-03', pillar: 'Brain', target: 'owner', industry_group: 'education', a: "Goals change depending on immediate pressure.", b: "Goals stay consistent for a full cycle to build progress." },
  // Pulse
  { id: 'EDU-PULSE-01', pillar: 'Pulse', target: 'owner', industry_group: 'education', a: "Teaching methods stay the same year to year.", b: "Teaching methods evolve based on what works." },
  { id: 'EDU-PULSE-02', pillar: 'Pulse', target: 'owner', industry_group: 'education', a: "Curriculum delivery is the main focus.", b: "Learning mastery is the main focus." },
  { id: 'EDU-PULSE-03', pillar: 'Pulse', target: 'owner', industry_group: 'education', a: "Remedial support happens when problems become big.", b: "Remedial support is built in early through assessment." },
  // Shield
  { id: 'EDU-SHIELD-01', pillar: 'Shield', target: 'owner', industry_group: 'education', a: "Policies exist but enforcement is informal.", b: "Policies are enforced with checklists and accountability." },
  { id: 'EDU-SHIELD-02', pillar: 'Shield', target: 'owner', industry_group: 'education', a: "Child safeguarding is assumed as common sense.", b: "Child safeguarding is structured with clear routines." },
  { id: 'EDU-SHIELD-03', pillar: 'Shield', target: 'owner', industry_group: 'education', a: "Data/records are stored wherever convenient.", b: "Data/records are stored with access control and backups." },
  // Tribe
  { id: 'EDU-TRIBE-01', pillar: 'Tribe', target: 'owner', industry_group: 'education', a: "Teachers prefer approval before trying something new.", b: "Teachers prefer clear boundaries so they can innovate safely." },
  { id: 'EDU-TRIBE-02', pillar: 'Tribe', target: 'owner', industry_group: 'education', a: "People avoid raising issues to keep peace.", b: "People raise issues early to protect learner outcomes." },

  // --- CONSTRUCTION / REAL ESTATE ---
  // Engine
  { id: 'CON-ENG-01', pillar: 'Engine', target: 'owner', industry_group: 'construction', a: "Project progress is managed through calls and WhatsApp updates.", b: "Project progress is managed through a simple schedule + task board." },
  { id: 'CON-ENG-02', pillar: 'Engine', target: 'owner', industry_group: 'construction', a: "Delays are handled as they appear.", b: "Delays are anticipated with buffer plans and weekly reviews." },
  { id: 'CON-ENG-03', pillar: 'Engine', target: 'owner', industry_group: 'construction', a: "Material usage is tracked informally.", b: "Material usage is tracked to reduce waste and theft." },
  { id: 'CON-ENG-04', pillar: 'Engine', target: 'owner', industry_group: 'construction', a: "Site quality varies by supervisor.", b: "Site quality is consistent due to checklists and standards." },
  { id: 'CON-ENG-05', pillar: 'Engine', target: 'owner', industry_group: 'construction', a: "Handoffs between teams are verbal.", b: "Handoffs use checklists to prevent rework." },
  // Fuel
  { id: 'CON-FUEL-01', pillar: 'Fuel', target: 'owner', industry_group: 'construction', a: "A project feels good when work is moving on site.", b: "A project feels good when cash collection stays ahead of costs." },
  { id: 'CON-FUEL-02', pillar: 'Fuel', target: 'owner', industry_group: 'construction', a: "We accept late payments to maintain relationships.", b: "We enforce payment milestones to protect cash flow." },
  { id: 'CON-FUEL-03', pillar: 'Fuel', target: 'owner', industry_group: 'construction', a: "Profit is estimated after completion.", b: "Profit is tracked during delivery to catch leaks early." },
  { id: 'CON-FUEL-04', pillar: 'Fuel', target: 'owner', industry_group: 'construction', a: "Variations are absorbed to keep the client happy.", b: "Variations are priced and approved to protect margin." },
  { id: 'CON-FUEL-05', pillar: 'Fuel', target: 'owner', industry_group: 'construction', a: "Labor costs drift without close review.", b: "Labor costs are tracked against output weekly." },
  // Voice
  { id: 'CON-VOICE-01', pillar: 'Voice', target: 'owner', industry_group: 'construction', a: "Work comes through referrals and networks.", b: "Work comes through a consistent pipeline (portfolio + follow-ups)." },
  { id: 'CON-VOICE-02', pillar: 'Voice', target: 'owner', industry_group: 'construction', a: "Proposals are customized each time.", b: "Proposals use standardized packages to reduce effort and increase clarity." },
  { id: 'CON-VOICE-03', pillar: 'Voice', target: 'owner', industry_group: 'construction', a: "We focus on 'what we build.'", b: "We focus on 'how we reduce client risk and deliver certainty.'" },
  // Brain
  { id: 'CON-BRAIN-01', pillar: 'Brain', target: 'owner', industry_group: 'construction', a: "Priorities change based on site emergencies.", b: "Priorities follow weekly planning to reduce emergencies." },
  { id: 'CON-BRAIN-02', pillar: 'Brain', target: 'owner', industry_group: 'construction', a: "Roles shift based on availability.", b: "Roles are clear so accountability stays stable." },
  { id: 'CON-BRAIN-03', pillar: 'Brain', target: 'owner', industry_group: 'construction', a: "Quality depends on supervisor experience.", b: "Quality depends on standards and inspections." },
  // Pulse
  { id: 'CON-PULSE-01', pillar: 'Pulse', target: 'owner', industry_group: 'construction', a: "We deliver using the same methods every time.", b: "We refine methods based on learning and defects." },
  { id: 'CON-PULSE-02', pillar: 'Pulse', target: 'owner', industry_group: 'construction', a: "Quality control is strongest at the end.", b: "Quality control happens at each milestone." },
  { id: 'CON-PULSE-03', pillar: 'Pulse', target: 'owner', industry_group: 'construction', a: "We adopt new tools slowly.", b: "We adopt tools that reduce rework and improve accuracy." },
  // Shield
  { id: 'CON-SHIELD-01', pillar: 'Shield', target: 'owner', industry_group: 'construction', a: "Agreements are sometimes informal if trust is high.", b: "Agreements are formal because disputes are expensive." },
  { id: 'CON-SHIELD-02', pillar: 'Shield', target: 'owner', industry_group: 'construction', a: "Scope changes are handled verbally.", b: "Scope changes use signed variation orders." },
  { id: 'CON-SHIELD-03', pillar: 'Shield', target: 'owner', industry_group: 'construction', a: "Safety is handled by experience.", b: "Safety is handled by checklists and enforcement." },
  { id: 'CON-SHIELD-04', pillar: 'Shield', target: 'owner', industry_group: 'construction', a: "Cash handling relies on trust.", b: "Cash handling relies on controls and approvals." },
  // Tribe
  { id: 'CON-TRIBE-01', pillar: 'Tribe', target: 'owner', industry_group: 'construction', a: "Site teams wait for approval to avoid blame.", b: "Site teams act within clear limits to maintain speed." },
  { id: 'CON-TRIBE-02', pillar: 'Tribe', target: 'owner', industry_group: 'construction', a: "People focus on their trade only.", b: "People coordinate across trades to reduce clashes." },

  // --- FINANCIAL SERVICES ---
  // Engine
  { id: 'FIN-ENG-01', pillar: 'Engine', target: 'owner', industry_group: 'finance', a: "Processing depends on staff experience and memory.", b: "Processing follows checklists and workflows." },
  { id: 'FIN-ENG-02', pillar: 'Engine', target: 'owner', industry_group: 'finance', a: "Client onboarding steps vary by officer.", b: "Client onboarding steps are standardized." },
  { id: 'FIN-ENG-03', pillar: 'Engine', target: 'owner', industry_group: 'finance', a: "Approvals are handled case-by-case.", b: "Approvals follow policy and limits." },
  { id: 'FIN-ENG-04', pillar: 'Engine', target: 'owner', industry_group: 'finance', a: "Files are managed across multiple places.", b: "Files are managed in a single controlled system." },
  { id: 'FIN-ENG-05', pillar: 'Engine', target: 'owner', industry_group: 'finance', a: "Reporting happens mainly when needed.", b: "Reporting happens on cadence to spot issues early." },
  // Fuel
  { id: 'FIN-FUEL-01', pillar: 'Fuel', target: 'owner', industry_group: 'finance', a: "Growth feels good when many clients are added.", b: "Growth feels good when risk and profitability stay healthy." },
  { id: 'FIN-FUEL-02', pillar: 'Fuel', target: 'owner', industry_group: 'finance', a: "Pricing/fees change based on competition.", b: "Pricing/fees follow cost, risk, and value logic." },
  { id: 'FIN-FUEL-03', pillar: 'Fuel', target: 'owner', industry_group: 'finance', a: "Collections are handled case-by-case.", b: "Collections follow a structured cadence and triggers." },
  { id: 'FIN-FUEL-04', pillar: 'Fuel', target: 'owner', industry_group: 'finance', a: "Loan/portfolio health is checked periodically.", b: "Loan/portfolio health is monitored continuously." },
  { id: 'FIN-FUEL-05', pillar: 'Fuel', target: 'owner', industry_group: 'finance', a: "We tolerate some leakage because it’s normal.", b: "We measure leakage so we can reduce it." },
  // Voice
  { id: 'FIN-VOICE-01', pillar: 'Voice', target: 'owner', industry_group: 'finance', a: "Clients come mainly through referrals and community trust.", b: "We run consistent acquisition with clear offers and follow-ups." },
  { id: 'FIN-VOICE-02', pillar: 'Voice', target: 'owner', industry_group: 'finance', a: "We sell products/features.", b: "We sell outcomes (security, speed, access, reliability)." },
  { id: 'FIN-VOICE-03', pillar: 'Voice', target: 'owner', industry_group: 'finance', a: "We assume clients understand terms.", b: "We explain terms clearly to reduce disputes and churn." },
  { id: 'FIN-VOICE-04', pillar: 'Voice', target: 'owner', industry_group: 'finance', a: "Follow-up is done when staff has time.", b: "Follow-up is structured and tracked." },
  // Brain
  { id: 'FIN-BRAIN-01', pillar: 'Brain', target: 'owner', industry_group: 'finance', a: "Policy exists but interpretation varies.", b: "Policy is translated into clear procedures and training." },
  { id: 'FIN-BRAIN-02', pillar: 'Brain', target: 'owner', industry_group: 'finance', a: "Decision-making is centralized to reduce risk.", b: "Decision-making is delegated with limits to reduce delays." },
  { id: 'FIN-BRAIN-03', pillar: 'Brain', target: 'owner', industry_group: 'finance', a: "Staff are judged by effort/volume.", b: "Staff are judged by quality and risk outcomes." },
  // Pulse
  { id: 'FIN-PULSE-01', pillar: 'Pulse', target: 'owner', industry_group: 'finance', a: "Products stay the same for long periods.", b: "Products evolve based on data and risk insights." },
  { id: 'FIN-PULSE-02', pillar: 'Pulse', target: 'owner', industry_group: 'finance', a: "Changes are made when complaints rise.", b: "Changes are made through controlled experiments." },
  { id: 'FIN-PULSE-03', pillar: 'Pulse', target: 'owner', industry_group: 'finance', a: "Client feedback is collected informally.", b: "Client feedback is collected systematically." },
  // Shield
  { id: 'FIN-SHIELD-01', pillar: 'Shield', target: 'owner', industry_group: 'finance', a: "Compliance is handled when regulators request it.", b: "Compliance is built into daily routines." },
  { id: 'FIN-SHIELD-02', pillar: 'Shield', target: 'owner', industry_group: 'finance', a: "Access to money/systems is broad to move fast.", b: "Access is controlled to reduce fraud." },
  { id: 'FIN-SHIELD-03', pillar: 'Shield', target: 'owner', industry_group: 'finance', a: "Password/security hygiene depends on individuals.", b: "Security hygiene is standardized (2FA, vault, audits)." },
  { id: 'FIN-SHIELD-04', pillar: 'Shield', target: 'owner', industry_group: 'finance', a: "Reconciliation is done when time allows.", b: "Reconciliation is done on schedule without exception." },
  // Tribe
  { id: 'FIN-TRIBE-01', pillar: 'Tribe', target: 'owner', industry_group: 'finance', a: "Staff prefer approvals because mistakes are costly.", b: "Staff prefer clear limits so work can move without fear." },
  { id: 'FIN-TRIBE-02', pillar: 'Tribe', target: 'owner', industry_group: 'finance', a: "People avoid raising issues until they’re sure.", b: "People raise early signals so risk is caught early." },

  // --- RETAIL (Examples) ---
  { id: 'RET-ENG-01', pillar: 'Engine', target: 'owner', industry_group: 'retail', a: "We notice stock-outs when customers complain.", b: "We use reorder points and alerts before stock runs out." },
  { id: 'RET-ENG-02', pillar: 'Engine', target: 'owner', industry_group: 'retail', a: "Pricing changes are handled manually at the counter.", b: "Prices are controlled via a simple system/POS rule." },
  { id: 'RET-FUEL-01', pillar: 'Fuel', target: 'owner', industry_group: 'retail', a: "I feel safe when stock levels are high.", b: "I feel safe when cash flow is strong even with lean stock." },
  { id: 'RET-FUEL-02', pillar: 'Fuel', target: 'owner', industry_group: 'retail', a: "Discounts are used to move stock quickly.", b: "Discounts follow margin rules so we don’t sell profit away." },
  { id: 'RET-SHIELD-01', pillar: 'Shield', target: 'owner', industry_group: 'retail', a: "We handle returns case-by-case.", b: "We have a clear returns policy to prevent fraud and loss." },

  // --- IT/TECH (Examples) ---
  { id: 'TECH-ENG-01', pillar: 'Engine', target: 'owner', industry_group: 'tech', a: "Tasks live in WhatsApp messages and memory.", b: "Work lives in a ticket/board with owners and deadlines." },
  { id: 'TECH-ENG-02', pillar: 'Engine', target: 'owner', industry_group: 'tech', a: "Bugs are fixed when someone complains loudly.", b: "Bugs are triaged with severity + SLA and tracked to closure." },
  { id: 'TECH-FUEL-01', pillar: 'Fuel', target: 'owner', industry_group: 'tech', a: "We bill after delivery to keep clients happy.", b: "We bill by milestones to protect cash flow." },
  { id: 'TECH-FUEL-02', pillar: 'Fuel', target: 'owner', industry_group: 'tech', a: "Scope changes are 'free adjustments.'", b: "Scope changes follow paid change requests." },
  { id: 'TECH-SHIELD-01', pillar: 'Shield', target: 'owner', industry_group: 'tech', a: "Client passwords are shared in chat.", b: "We use a password vault and 2FA for all client access." },

  // --- AGRICULTURE (Examples) ---
  { id: 'AG-ENG-01', pillar: 'Engine', target: 'owner', industry_group: 'agriculture', a: "We estimate input needs roughly and adjust later.", b: "We plan inputs with a season budget and track usage." },
  { id: 'AG-ENG-02', pillar: 'Engine', target: 'owner', industry_group: 'agriculture', a: "Loss is accepted as normal after harvest.", b: "We measure loss and install handling/storage routines to reduce it." },
  { id: 'AG-FUEL-01', pillar: 'Fuel', target: 'owner', industry_group: 'agriculture', a: "Cash planning is difficult because seasons vary.", b: "We plan seasonal cash flow and protect reserves." },
  { id: 'AG-SHIELD-01', pillar: 'Shield', target: 'owner', industry_group: 'agriculture', a: "Buyer agreements are verbal.", b: "We use written buyer contracts to prevent price disputes." },

  // --- HOSPITALITY (Examples) ---
  { id: 'HOS-ENG-01', pillar: 'Engine', target: 'owner', industry_group: 'hospitality', a: "Service quality depends on which staff are on duty.", b: "Service quality stays consistent due to standards and checklists." },
  { id: 'HOS-ENG-02', pillar: 'Engine', target: 'owner', industry_group: 'hospitality', a: "Stock-outs happen during rush hours.", b: "We forecast supplies and maintain par levels." },
  { id: 'HOS-FUEL-01', pillar: 'Fuel', target: 'owner', industry_group: 'hospitality', a: "Profit is judged by busy days.", b: "Profit is judged by margin after waste, refunds, and staffing." },
  { id: 'HOS-SHIELD-01', pillar: 'Shield', target: 'owner', industry_group: 'hospitality', a: "Refunds are handled emotionally.", b: "Refunds follow policies that protect revenue." },
];

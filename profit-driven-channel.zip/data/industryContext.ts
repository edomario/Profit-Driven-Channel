
// ... existing imports and types ...
import { KPI } from "../types";

export type IndustryKey = 'retail' | 'tech' | 'agriculture' | 'hospitality' | 'services' | 'transport' | 'manufacturing' | 'construction' | 'other';

export interface Lexicon {
  customer: string;
  order: string;
  delivery: string;
  stock: string;
  lead: string;
  quality: string;
  cash_risk: string;
  staff: string;
}

// Map industry ID to specific leak symptoms for Mission Brief
export const INDUSTRY_LEAK_TOKENS: Record<string, string[]> = {
  retail: ['stock-outs', 'shrinkage', 'expiry loss', 'supplier terms'],
  construction: ['variations', 'milestone payments', 'rework', 'disputes'],
  tech: ['scope creep', 'delivery SLAs', 'backlog', 'rework bugs'],
  hospitality: ['reviews', 'cancellations', 'waste', 'service time'],
  health: ['waiting time', 'incidents', 'compliance', 'records'],
  education: ['fee collection', 'teacher coaching', 'learning outcomes'],
  finance: ['PAR', 'fraud controls', 'reconciliation', 'audit trails'],
  agriculture: ['post-harvest loss', 'buyer contracts', 'logistics delays'],
  transport: ['breakdowns', 'fuel theft', 'idle fleet', 'delivery delays'],
  manufacturing: ['scrap rate', 'downtime', 'batch defects', 'supply delays'],
  services: ['unbilled hours', 'scope creep', 'client churn', 'proposal delays'],
  other: ['waste', 'delays', 'inconsistency', 'rework']
};

export const INDUSTRY_LEXICONS: Record<string, Lexicon> = {
  retail: {
    customer: 'customer',
    order: 'sale',
    delivery: 'delivery/pickup',
    stock: 'inventory',
    lead: 'WhatsApp DM/call',
    quality: 'packaging/condition',
    cash_risk: 'dead stock',
    staff: 'staff'
  },
  tech: {
    customer: 'client',
    order: 'project/sprint',
    delivery: 'handover/milestone',
    stock: 'backlog/tickets',
    lead: 'proposal/discovery call',
    quality: 'bugs/QA',
    cash_risk: 'scope creep',
    staff: 'developers'
  },
  agriculture: {
    customer: 'buyer/aggregator',
    order: 'harvest lot/supply deal',
    delivery: 'collection/transport',
    stock: 'produce/inputs',
    lead: 'buyer lead/contract',
    quality: 'grading/moisture',
    cash_risk: 'spoilage',
    staff: 'workers'
  },
  hospitality: {
    customer: 'guest/diner',
    order: 'booking/order',
    delivery: 'service experience',
    stock: 'supplies',
    lead: 'booking inquiry',
    quality: 'reviews/cleanliness',
    cash_risk: 'no-shows',
    staff: 'crew'
  },
  services: {
    customer: 'client',
    order: 'retainer',
    delivery: 'deliverable',
    stock: 'capacity',
    lead: 'consultation',
    quality: 'accuracy',
    cash_risk: 'unbilled hours',
    staff: 'consultants'
  },
  transport: {
    customer: 'shipper',
    order: 'load',
    delivery: 'trip',
    stock: 'fleet',
    lead: 'quote request',
    quality: 'safety/timeliness',
    cash_risk: 'breakdowns',
    staff: 'drivers'
  },
  manufacturing: {
    customer: 'distributor',
    order: 'batch',
    delivery: 'shipping',
    stock: 'raw materials',
    lead: 'purchase order',
    quality: 'defect rate',
    cash_risk: 'scrap',
    staff: 'operators'
  },
  construction: {
    customer: 'property owner',
    order: 'job',
    delivery: 'milestone',
    stock: 'materials',
    lead: 'bid/tender',
    quality: 'finish',
    cash_risk: 'delays',
    staff: 'crew'
  },
  other: {
    customer: 'customer',
    order: 'order',
    delivery: 'delivery',
    stock: 'resources',
    lead: 'lead',
    quality: 'quality',
    cash_risk: 'waste',
    staff: 'team'
  }
};

export interface IndustryCategory {
  id: string;
  label: string;
  iconName: string; 
  lexiconKey: IndustryKey;
  subIndustries: string[];
}

export const INDUSTRY_TAXONOMY: IndustryCategory[] = [
  {
    id: 'agriculture',
    label: 'Agriculture & Agribusiness',
    iconName: 'Sprout',
    lexiconKey: 'agriculture',
    subIndustries: [
      'Crop farming', 'Livestock', 'Dairy & milk collection', 'Fisheries & aquaculture',
      'Agro-processing', 'Input supplier', 'Farm services', 'Produce aggregation & trading',
      'Export / cross-border produce trade', 'Storage & warehousing'
    ]
  },
  {
    id: 'retail',
    label: 'Retail, Wholesale & Trade',
    iconName: 'ShoppingBag',
    lexiconKey: 'retail',
    subIndustries: [
      'Supermarket / mini-mart', 'Boutique / fashion', 'Electronics & phone shop',
      'Hardware & building materials', 'Pharmacy / drug shop', 'Cosmetics / beauty supplies',
      'Stationery / printing shop', 'FMCG wholesaler / distributor', 'Market vendor / kiosk',
      'Import / export trading'
    ]
  },
  {
    id: 'manufacturing',
    label: 'Manufacturing & Production',
    iconName: 'Factory',
    lexiconKey: 'manufacturing',
    subIndustries: [
      'Food & beverage production', 'Furniture & carpentry', 'Metal works / welding',
      'Textile / garment production', 'Packaging manufacturing', 'Brick/block making',
      'Soap / chemicals', 'Water / ice production', 'Craft production'
    ]
  },
  {
    id: 'construction',
    label: 'Construction & Real Estate',
    iconName: 'HardHat',
    lexiconKey: 'construction',
    subIndustries: [
      'Building contractor', 'Civil works / road works', 'Architecture / design',
      'Plumbing / electrical services', 'Interior design', 'Real estate agency',
      'Property management', 'Land surveying', 'Quarry / sand supplier'
    ]
  },
  {
    id: 'transport',
    label: 'Transport & Logistics',
    iconName: 'Truck',
    lexiconKey: 'transport',
    subIndustries: [
      'Taxi / boda / ride services', 'Trucking / haulage', 'Courier / last-mile',
      'Warehousing & fulfillment', 'Freight forwarding', 'Fleet management',
      'Fuel station', 'Car hire / rental'
    ]
  },
  {
    id: 'hospitality',
    label: 'Hospitality & Tourism',
    iconName: 'Utensils',
    lexiconKey: 'hospitality',
    subIndustries: [
      'Restaurant / café', 'Bar / events venue', 'Hotel / lodge / Airbnb',
      'Catering services', 'Bakery / snacks', 'Travel agency / tours',
      'Conference management', 'Fast food / takeaway'
    ]
  },
  {
    id: 'health',
    label: 'Health & Wellness',
    iconName: 'HeartPulse',
    lexiconKey: 'services',
    subIndustries: [
      'Clinic / hospital', 'Dental services', 'Laboratory services',
      'Nursing / home care', 'Gym / fitness center', 'Saloon / spa',
      'Traditional/herbal health'
    ]
  },
  {
    id: 'education',
    label: 'Education & Training',
    iconName: 'BookOpen',
    lexiconKey: 'services',
    subIndustries: [
      'Nursery / primary / secondary', 'Vocational training', 'Tutoring / coaching',
      'University services', 'EdTech / online learning', 'Bookshop', 'Kids services'
    ]
  },
  {
    id: 'finance',
    label: 'Financial Services',
    iconName: 'Wallet',
    lexiconKey: 'services',
    subIndustries: [
      'SACCO / microfinance', 'Money lending', 'Insurance agency',
      'Accounting / bookkeeping', 'Audit & tax services', 'Investment advisory',
      'Payments / fintech'
    ]
  },
  {
    id: 'tech',
    label: 'Technology & IT',
    iconName: 'Monitor',
    lexiconKey: 'tech',
    subIndustries: [
      'Software company / SaaS', 'IT support & repair', 'Web design',
      'Digital marketing agency', 'Cybersecurity services', 'Data analytics',
      'Telecom/ISP reseller', 'Hardware installation'
    ]
  },
  {
    id: 'media',
    label: 'Media & Creative',
    iconName: 'Video',
    lexiconKey: 'services',
    subIndustries: [
      'Photography / videography', 'Printing & branding', 'Graphic design',
      'Content creation', 'PR / communications', 'Legal services', 'Consulting',
      'Recruitment / HR'
    ]
  },
  {
    id: 'ngo',
    label: 'NGO & Social Enterprise',
    iconName: 'Globe',
    lexiconKey: 'services',
    subIndustries: [
      'NGO / charity', 'Church/ministry', 'Community organization (CBO)',
      'Youth/women programs', 'Donor-funded projects', 'Social enterprise'
    ]
  },
  {
    id: 'automotive',
    label: 'Automotive & Machinery',
    iconName: 'Wrench',
    lexiconKey: 'services',
    subIndustries: [
      'Garage / mechanic', 'Car wash', 'Spare parts dealer',
      'Tyres & battery shop', 'Heavy machinery repair', 'Motorcycle repair'
    ]
  },
  {
    id: 'utilities',
    label: 'Utilities & Essential',
    iconName: 'Zap',
    lexiconKey: 'other',
    subIndustries: [
      'Water supply', 'Waste collection', 'Solar/energy installation',
      'Security company', 'Cleaning services', 'Laundry services'
    ]
  },
  {
    id: 'household',
    label: 'Household & Personal',
    iconName: 'Home',
    lexiconKey: 'services',
    subIndustries: [
      'Tailoring', 'Domestic staffing', 'Event decoration',
      'Coaching / counseling', 'Moving services'
    ]
  }
];

export interface QuickScanVariant {
  pillar: string;
  variants: Record<string, { a: string, b: string }>; // Keyed by industry ID, fallback to 'default'
}

export const QUICK_SCAN_QUESTIONS: QuickScanVariant[] = [
  {
    pillar: 'Engine',
    variants: {
      retail: { a: "I personally handle issues at the counter to keep things moving.", b: "We have a simple routine so issues don't repeat." },
      tech: { a: "I jump in to fix delivery problems myself to meet deadlines.", b: "We improve the workflow tickets so the same issues don't return." },
      agriculture: { a: "I solve field/collection problems myself when they happen.", b: "We use a clear process/checklist so the same breakdown doesn't happen again." },
      hospitality: { a: "I personally step in when service goes wrong to protect the guest experience.", b: "We tighten the service process so the same failure doesn't repeat." },
      default: { a: "When something breaks, I jump in fast so we don't lose the client.", b: "When something breaks, I fix the process so we stop paying the 'mistake tax'." }
    }
  },
  {
    pillar: 'Fuel',
    variants: {
      retail: { a: "I judge a good month by sales volume and stock movement.", b: "I judge a good month by profit margin + cash left after expenses." },
      tech: { a: "I feel successful when we sign projects and get work coming in.", b: "I feel successful when projects leave profit after delivery costs." },
      agriculture: { a: "A good season means we sold a lot.", b: "A good season means we kept strong margin after inputs and losses." },
      hospitality: { a: "A good month means high bookings/orders.", b: "A good month means healthy profit after refunds, waste, and staffing." },
      default: { a: "I watch total sales because momentum keeps the business alive.", b: "I watch net profit because sales without margin is 'busy broke'." }
    }
  },
  {
    pillar: 'Voice',
    variants: {
      retail: { a: "We rely mostly on walk-ins and referrals.", b: "We consistently run a lead system (ads/offers) even when busy." },
      tech: { a: "We rely on referrals and 'who knows us'.", b: "We run a consistent pipeline (content, outreach, proposals)." },
      agriculture: { a: "Buyers find us when it's harvest time.", b: "We actively line up buyers/contracts before harvest." },
      hospitality: { a: "We depend on location and repeat guests naturally.", b: "We actively drive bookings with offers, reviews, and follow-up." },
      default: { a: "We post when inspired because authenticity sells.", b: "We post on schedule because consistency compounds attention." }
    }
  },
  {
    pillar: 'Brain',
    variants: {
      retail: { a: "People do whatever is urgent that day.", b: "People know their responsibilities and what 'good performance' looks like." },
      tech: { a: "Work priorities change based on the loudest client message.", b: "We use clear priorities, owners, and weekly targets." },
      agriculture: { a: "We decide day-by-day depending on what happens.", b: "We plan activities (inputs, labor) with clear owners and targets." },
      hospitality: { a: "Staff react to the rush and solve problems as they come.", b: "Staff follow clear standards and targets (service time, quality)." },
      default: { a: "I carry the vision because founders should be the compass.", b: "We write the vision because clarity reduces confusion." }
    }
  },
  {
    pillar: 'Pulse',
    variants: {
      retail: { a: "We sell what has always sold; we adjust slowly.", b: "We regularly improve offers/stock based on demand data." },
      tech: { a: "We deliver the same service package; improvements are occasional.", b: "We upgrade our offers quarterly based on results + feedback." },
      agriculture: { a: "We keep doing the same practices each season.", b: "We improve each season (quality, yields) using results." },
      hospitality: { a: "Our experience is stable; we change only when complaints force it.", b: "We actively improve the experience to increase reviews." },
      default: { a: "We build what excites us because passion creates great work.", b: "We build what evidence demands because relevance creates revenue." }
    }
  },
  {
    pillar: 'Shield',
    variants: {
      retail: { a: "We run mostly on trust and common sense.", b: "We enforce protections (contracts, access control, 2FA)." },
      tech: { a: "We start work fast and trust the relationship.", b: "We protect delivery with scope, change requests, and 2FA." },
      agriculture: { a: "We rely on trust and handshake arrangements.", b: "We protect the business with agreements and records." },
      hospitality: { a: "We handle issues when they come up.", b: "We prevent damage with clear policies and access discipline." },
      default: { a: "We move fast on trust because speed wins deals.", b: "We formalize terms because one dispute can erase profit." }
    }
  },
  {
    pillar: 'Tribe',
    variants: {
      retail: { a: "Staff wait for approval to avoid making mistakes.", b: "Staff solve common issues confidently using guidelines." },
      tech: { a: "People ask for approval before acting to stay safe.", b: "People act within decision rights and report outcomes." },
      agriculture: { a: "Workers wait for instruction before taking action.", b: "Workers follow clear routines and take initiative within limits." },
      hospitality: { a: "Staff escalate everything to avoid blame.", b: "Staff handle routine guest issues confidently." },
      default: { a: "I prefer to confirm with my manager before I start.", b: "I prefer to start with my best judgment, then update." }
    }
  }
];

export interface PillarWeights {
  brain: number;
  voice: number;
  engine: number;
  fuel: number;
  pulse: number;
  shield: number;
  tribe: number;
}

export interface IndustryData {
  weights: PillarWeights;
  kpis: KPI[];
  overrides?: Record<string, Partial<PillarWeights>>; // Key is subIndustry (lowercase)
}

export const INDUSTRY_DATA: Record<string, IndustryData> = {
  // ... (keeping existing INDUSTRY_DATA as is, truncated for brevity) ...
  agriculture: {
    weights: { engine: 18, fuel: 18, pulse: 16, shield: 14, voice: 14, brain: 10, tribe: 10 },
    kpis: []
  },
  retail: {
    weights: { voice: 18, fuel: 18, engine: 16, pulse: 14, shield: 12, brain: 11, tribe: 11 },
    kpis: []
  },
  manufacturing: {
    weights: { engine: 20, pulse: 16, fuel: 16, shield: 14, tribe: 12, brain: 12, voice: 10 },
    kpis: []
  },
  construction: {
    weights: { shield: 18, engine: 17, fuel: 17, brain: 13, tribe: 13, voice: 12, pulse: 10 },
    kpis: []
  },
  transport: {
    weights: { engine: 18, shield: 16, fuel: 16, tribe: 14, brain: 12, voice: 12, pulse: 12 },
    kpis: []
  },
  hospitality: {
    weights: { voice: 18, pulse: 17, engine: 15, tribe: 15, fuel: 14, shield: 11, brain: 10 },
    kpis: []
  },
  health: {
    weights: { shield: 20, engine: 16, tribe: 15, voice: 13, fuel: 13, brain: 12, pulse: 11 },
    kpis: []
  },
  education: {
    weights: { brain: 18, tribe: 18, engine: 14, voice: 12, fuel: 12, shield: 13, pulse: 13 },
    kpis: []
  },
  finance: {
    weights: { shield: 22, fuel: 18, brain: 15, engine: 13, voice: 12, tribe: 10, pulse: 10 },
    kpis: []
  },
  tech: {
    weights: { engine: 18, voice: 16, pulse: 16, shield: 14, brain: 14, tribe: 12, fuel: 10 },
    kpis: []
  },
  media: {
    weights: { voice: 18, brain: 15, engine: 14, pulse: 14, fuel: 14, tribe: 13, shield: 12 },
    kpis: []
  },
  ngo: {
    weights: { brain: 18, shield: 16, engine: 14, tribe: 14, fuel: 13, voice: 13, pulse: 12 },
    kpis: []
  },
  utilities: {
    weights: { shield: 18, engine: 18, tribe: 14, fuel: 14, brain: 12, pulse: 12, voice: 12 },
    kpis: []
  },
  automotive: {
    weights: { engine: 18, pulse: 16, shield: 15, fuel: 15, tribe: 13, voice: 12, brain: 11 },
    kpis: []
  },
  household: {
    weights: { voice: 18, tribe: 16, engine: 14, fuel: 14, pulse: 13, shield: 13, brain: 12 },
    kpis: []
  }
};
